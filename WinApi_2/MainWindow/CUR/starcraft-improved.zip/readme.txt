﻿=== StarCraft Improved Cursor Set ===

By: primathon

Download: http://www.rw-designer.com/cursor-set/starcraft-improved

Author's description:

Default StarCraft 1 cursors, improved framerate and color blending

Originally created by Blizzard Entertainment

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.